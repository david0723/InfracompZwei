
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.math.BigInteger;
import java.net.Socket;
import java.security.InvalidKeyException;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.SecureRandom;
import java.security.Security;
import java.security.SignatureException;
import java.security.cert.CertificateEncodingException;
import java.security.cert.X509Certificate;
import java.util.Date;

import javax.security.auth.x500.X500Principal;

import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.x509.X509V1CertificateGenerator;

public class Client 
{	
	public static final String HOLA = "HOLA";
	public static final String INICIO = "INICIO";
	public static final String ALGS = "AES";
	public static final String ALGA = "RSA";
	public static final String ALGD = "HMACMD5";
	public static final String SERVER = "localhost";
	public static final int PUERTO443 = 443;
	public static final int PUERTO80 = 80;
	public static final String CERCLNT = "CERCLNT";
	public static final String ALGORITMOS = "ALGORITMOS";
	public static final String INIT = "INIT";

	//Posicion a enviar
	public static final String POSICION = "4124.2028,210.4418";

	
	private Socket socket;
	private BufferedReader br;
	private InputStream input;
	private generator gen;
	public Client() throws Exception
	{
		gen = new generator();
		Security.addProvider(new org.bouncycastle.jce.provider.BouncyCastleProvider());
	}
	
	public void ejecutar() throws Exception
	{

			socket = new Socket(SERVER, PUERTO443);
			br = new BufferedReader(new InputStreamReader(socket.getInputStream()));
			input = socket.getInputStream();
			new PrintWriter(new OutputStreamWriter(socket.getOutputStream()), true);
			PrintStream p = new PrintStream(socket.getOutputStream());
			
			//Inicio de Ejecucion
			System.out.println("Cliente: "+HOLA);
			p.println(HOLA);
			String respuesta = br.readLine();
			System.out.println("Servidor: "+respuesta);
			
			if(respuesta.equals(INICIO))
			{
				String algoritmos = ALGORITMOS+":"+ALGS+":"+ALGA+":"+ALGD;
				System.out.println("Cliente: "+algoritmos);
				p.println(algoritmos);
				
				respuesta = br.readLine();
				System.out.println("Servidor: "+respuesta);
				
				if(respuesta.equals("ESTADO:OK"))
				{
					System.out.println("Cliente: "+CERCLNT);
					p.println(CERCLNT);
					
//					gen.generarLlavesAsimetricas();
//					java.security.cert.X509Certificate certificate = cif.generateSelfSignedX509Certificate();
//					byte[] bytesCertificate = certificate.getEncoded();
//					p.write(bytesCertificate);
//					p.flush();
					gen.generarLlavesAsimetricas();
					java.security.cert.X509Certificate cert = gen.generateSelfSignedX509Certificate();
					byte[] mybyte = cert.getEncoded();
					p.write(mybyte);
					p.flush();
					
					respuesta = br.readLine();
					
					if(respuesta.equals("CERTSRV"))
					{
						System.out.println("Servidor: "+respuesta);
						
						byte[] certificado = new byte[2000];
						input.read(certificado, 0, certificado.length);
						gen.verificarCertificado(certificado);
						
						
						respuesta = br.readLine();
						
						
						if(respuesta.startsWith("INIT"))
						{
							System.out.println("Servidor: "+respuesta);
							
							String code = respuesta.split(":")[1];
							System.out.println(code);
							
							byte[] codeBytes =gen.toByteArray(code);
							gen.generarLlaveSesion(codeBytes);
							
							System.out.println("Sending ACT 1");
							String ACT1 = "ACT1:"+gen.toHexString(gen.cifrarSimetrico(POSICION.getBytes()));
							p.println(ACT1);
							p.flush();
							
							System.out.println("Sending ACT 2");
							String ACT2 = "ACT2:"+gen.toHexString(gen.cifrarAsimetrico( gen.md5(POSICION.getBytes()) ));
							p.println(ACT2);
							p.flush();
							
							System.out.println("waiting for response");
							respuesta = br.readLine();
							System.out.println("Servidor: "+respuesta);
						}
					}
				}
			}
		
		

	}
	
	
	public static void main(String[] args) throws Exception 
	{
		Client cliente = new Client();
		
		try
		{
			cliente.ejecutar();
		}
		
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	

}