import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.security.*;
import java.security.cert.CertificateEncodingException;
import java.security.cert.X509Certificate;
import java.util.Date;

import javax.crypto.Cipher;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import javax.security.auth.x500.X500Principal;
import javax.xml.bind.DatatypeConverter;

import org.bouncycastle.crypto.digests.MD5Digest;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.x509.X509V1CertificateGenerator;


public class generator 
{
	private final static String ALGORITMO_A="RSA";
	private final static String ALGORITMO_S="AES";
	private final static String ALGORITMO_D="HMACMD5";
	private final static String PADDING="AES/ECB/PKCS5Padding";
	
	private KeyPair keyPair;
	private SecretKeySpec key;
	private PublicKey pKey; 
	
	
	public PublicKey getpKey() {
		return pKey;
	}

	public void setpKey(PublicKey pKey) {
		this.pKey = pKey;
	}

	public KeyPair getKeyPair() {
		return keyPair;
	}

	public void setKeyPair(KeyPair keyPair) {
		this.keyPair = keyPair;
	}

	public generator()
	{
		Security.addProvider(new BouncyCastleProvider());
	}

	public void generarLlavesAsimetricas() throws NoSuchAlgorithmException, NoSuchProviderException
	{
		// GENERATE THE PUBLIC/PRIVATE RSA KEY PAIR
		KeyPairGenerator keyPairGenerator = KeyPairGenerator.getInstance("RSA", "BC");
		keyPairGenerator.initialize(1024, new SecureRandom());
		
		keyPair = keyPairGenerator.generateKeyPair();
	}
	
    public X509Certificate generateSelfSignedX509Certificate() throws NoSuchAlgorithmException, NoSuchProviderException, CertificateEncodingException,
    SignatureException, InvalidKeyException, IOException {

	Security.addProvider(new BouncyCastleProvider());
	
	// yesterday
	Date validityBeginDate = new Date(System.currentTimeMillis() - 24 * 60 * 60 * 1000);
	// in 2 years
	Date validityEndDate = new Date(System.currentTimeMillis() + 2 * 365 * 24 * 60 * 60 * 1000);
	
	
	
	// GENERATE THE X509 CERTIFICATE
	X509V1CertificateGenerator certGen = new X509V1CertificateGenerator();
	X500Principal dnName = new X500Principal("CN=Cliente");
	
	certGen.setSerialNumber(BigInteger.valueOf(System.currentTimeMillis()));
	certGen.setSubjectDN(dnName);
	certGen.setIssuerDN(dnName); // use the same
	certGen.setNotBefore(validityBeginDate);
	certGen.setNotAfter(validityEndDate);
	certGen.setPublicKey(keyPair.getPublic());
	certGen.setSignatureAlgorithm("MD5WITHRSAENCRYPTION");
	
	X509Certificate cert = certGen.generate(keyPair.getPrivate(), "BC");
	
	return cert;
	
	
	
	//// DUMP CERTIFICATE AND KEY PAIR
	//System.out.println(Strings.repeat("=", 80));
	//System.out.println("CERTIFICATE TO_STRING");
	//System.out.println(Strings.repeat("=", 80));
	//System.out.println();
	//System.out.println(cert);
	//System.out.println();
	//
	//System.out.println(Strings.repeat("=", 80));
	//System.out.println("CERTIFICATE PEM (to store in a cert-johndoe.pem file)");
	//System.out.println(Strings.repeat("=", 80));
	//System.out.println();
	//PEMWriter pemWriter = new PEMWriter(new PrintWriter(System.out));
	//pemWriter.writeObject(cert);
	//pemWriter.flush();
	//System.out.println();
	//
	//System.out.println(Strings.repeat("=", 80));
	//System.out.println("PRIVATE KEY PEM (to store in a priv-johndoe.pem file)");
	//System.out.println(Strings.repeat("=", 80));
	//System.out.println();
	//pemWriter.writeObject(keyPair.getPrivate());
	//pemWriter.flush();
	
	
	}
	
	
	
    public void descifrar(byte[] cipheredText) 
    {
    	System.out.println("descifrar");
    	try 
    	{
    		Cipher cipher = Cipher.getInstance(ALGORITMO_A);
    		cipher.init(Cipher.DECRYPT_MODE, keyPair.getPrivate());
    		byte [] clearText = cipher.doFinal(cipheredText);
    		String s3 = new String(clearText);
    		System.out.println("clave original: " + s3);
    	}
    	catch (Exception e) 
    	{
    		System.out.println("Excepcion: " + e.getMessage());
    	}
    }
    
	public void generarLlaveSesion(byte[] session) throws Exception
	{
		try 
		{
			Cipher cipher = Cipher.getInstance(ALGORITMO_A);
			cipher.init(Cipher.DECRYPT_MODE, keyPair.getPrivate());
			byte [] textoPlano = cipher.doFinal(session);
			key = new SecretKeySpec(textoPlano, ALGORITMO_S);
		} 

		catch (Exception e) 
		{
			// TODO: handle exception
			e.printStackTrace();
		}
	}

	public byte[] cifrarSimetrico(byte[] codigo) 
	{
		byte [] cipheredText;
		try {

			Cipher cipher = Cipher.getInstance(PADDING);

			cipher.init(Cipher.ENCRYPT_MODE, key);

			cipheredText = cipher.doFinal(codigo);


			return cipheredText;
		}
		catch (Exception e) {
			System.out.println("Excepcion: " + e.getMessage());
			return null;
		}
	}
	public byte[] cifrarAsimetrico(byte[] code) 
	{
		try {

			Cipher cipher = Cipher.getInstance(ALGORITMO_A);

			cipher.init(Cipher.ENCRYPT_MODE, pKey);

			byte [] cipheredText = cipher.doFinal(code);
			return cipheredText;
		}
		catch (Exception e) {
			System.out.println("Excepcion: " + e.getMessage());
			return null;
		}
	}
	public byte[] hexStringToByteArray(String s) 
	{
	    int len = s.length();
	    byte[] data = new byte[len / 2];
	    for (int i = 0; i < len; i += 2) {
	        data[i / 2] = (byte) ((Character.digit(s.charAt(i), 16) << 4) + Character.digit(s.charAt(i+1), 16));
	    }
	    return data;
	}
	
	public String bytesToHex(byte[] bytes) 
	{
		char[] hexArray = "0123456789ABCDEF".toCharArray();
	    char[] hexChars = new char[bytes.length * 2];
	    for ( int j = 0; j < bytes.length; j++ ) {
	        int v = bytes[j] & 0xFF;
	        hexChars[j * 2] = hexArray[v >>> 4];
	        hexChars[j * 2 + 1] = hexArray[v & 0x0F];
	    }
	    return new String(hexChars);
	}

	public String toHexString(byte[] array) {
	    return DatatypeConverter.printHexBinary(array);
	}

	public byte[] toByteArray(String s) {
	    return DatatypeConverter.parseHexBinary(s);
	}

	public String md5Java(String message)
	{ 
		String digest = null;
		try {
				MessageDigest md = MessageDigest.getInstance("MD5"); 
				byte[] hash = md.digest(message.getBytes("UTF-8")); //converting byte array to Hexadecimal String
				StringBuilder sb = new StringBuilder(2*hash.length); 
				for(byte b : hash)
				{ 
					sb.append(String.format("%02x", b&0xff)); 
				} 
				digest = sb.toString(); 
			}
		
		catch (UnsupportedEncodingException ex){ ex.printStackTrace(); } 
		catch (NoSuchAlgorithmException ex) { ex.printStackTrace(); } 
		return digest; 
	}
	public byte[] md5(byte[] b) throws NoSuchAlgorithmException, InvalidKeyException
	{
		SecretKeySpec keySpec = new SecretKeySpec( key.getEncoded(),"HmacMD5");

		Mac mac = Mac.getInstance("HmacSHA1");
		mac.init(keySpec);
		byte[] result = mac.doFinal(b);
		return result;

		}
	
	public void verificarCertificado(byte[] datosCertificado) 
	{
		try
		{
			javax.security.cert.X509Certificate certificado = javax.security.cert.X509Certificate.getInstance(datosCertificado);   
			certificado.checkValidity();
			pKey = certificado.getPublicKey();
			
		} 

		catch (Exception e)
		{
			e.printStackTrace();
		}
	}

}

