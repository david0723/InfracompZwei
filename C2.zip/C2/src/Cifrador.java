import java.io.IOException;
import java.math.BigInteger;
import java.security.InvalidKeyException;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.Security;
import java.security.SignatureException;
import java.security.cert.CertificateEncodingException;
import java.util.Date;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import javax.security.auth.x500.X500Principal;
import javax.security.cert.X509Certificate;

import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.x509.X509V1CertificateGenerator;

public class Cifrador 
{
	//Cifrado Simetrico
	public final static String SIMETRICO = "AES";
	private final static int TAMANO_LLAVE_AES = 128;
	public final static String PADDING_SIMETRICO = "AES/ECB/PKCS5Padding";
	private SecretKey secretKeyAES;

	//Cifrado Asimetrico
	public final static String	ASIMETRICO ="RSA";
	private final static int TAMANO_LLAVE_RSA = 1024;
	private KeyPair keyPairRSA;
	private PublicKey publicKeyRSA;
	private PrivateKey privateKeyRSA;
	private PublicKey publicKeyServer;

	//Digest
	private final static String DIGEST = "SHA";
	private KeyPair keyPairSHA;

	//Llave de sesion
	private SecretKeySpec sessionKey; 

	//Separador
	public final static String PUNTO_COMA = ";";

	public Cifrador() throws Exception
	{
		try
		{
			//Generar llaves RSA
			Security.addProvider(new BouncyCastleProvider());
			KeyPairGenerator keyGenerator = KeyPairGenerator.getInstance(ASIMETRICO);
			keyGenerator.initialize(TAMANO_LLAVE_RSA);  
			KeyPair pairKey = keyGenerator.generateKeyPair();
			PrivateKey privateKey = pairKey.getPrivate();
			PublicKey publicKey = pairKey.getPublic();
			publicKeyRSA = publicKey;
			privateKeyRSA = privateKey;

			//Generar llave AES
			KeyGenerator keyGenerator2 = KeyGenerator.getInstance(SIMETRICO, "BC");
			keyGenerator2.init(TAMANO_LLAVE_AES);
			secretKeyAES = keyGenerator2.generateKey();

		}

		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

	public java.security.cert.X509Certificate generateSelfSignedX509Certificate() throws NoSuchAlgorithmException, NoSuchProviderException, CertificateEncodingException,
    SignatureException, InvalidKeyException, IOException {

	Security.addProvider(new BouncyCastleProvider());
	
	// yesterday
	Date validityBeginDate = new Date(System.currentTimeMillis() - 24 * 60 * 60 * 1000);
	// in 2 years
	Date validityEndDate = new Date(System.currentTimeMillis() + 2 * 365 * 24 * 60 * 60 * 1000);
	
	// GENERATE THE PUBLIC/PRIVATE RSA KEY PAIR
	KeyPairGenerator keyPairGenerator = KeyPairGenerator.getInstance("RSA", "BC");
	keyPairGenerator.initialize(1024, new SecureRandom());
	
	KeyPair keyPair = keyPairGenerator.generateKeyPair();
	
	
	// GENERATE THE X509 CERTIFICATE
	X509V1CertificateGenerator certGen = new X509V1CertificateGenerator();
	X500Principal dnName = new X500Principal("CN=Cliente");
	
	certGen.setSerialNumber(BigInteger.valueOf(System.currentTimeMillis()));
	certGen.setSubjectDN(dnName);
	certGen.setIssuerDN(dnName); // use the same
	certGen.setNotBefore(validityBeginDate);
	certGen.setNotAfter(validityEndDate);
	certGen.setPublicKey(keyPair.getPublic());
	certGen.setSignatureAlgorithm("MD5WITHRSAENCRYPTION");
	
	java.security.cert.X509Certificate cert = certGen.generate(keyPair.getPrivate(), "BC");
	
	return cert;
	
	
	
	//// DUMP CERTIFICATE AND KEY PAIR
	//System.out.println(Strings.repeat("=", 80));
	//System.out.println("CERTIFICATE TO_STRING");
	//System.out.println(Strings.repeat("=", 80));
	//System.out.println();
	//System.out.println(cert);
	//System.out.println();
	//
	//System.out.println(Strings.repeat("=", 80));
	//System.out.println("CERTIFICATE PEM (to store in a cert-johndoe.pem file)");
	//System.out.println(Strings.repeat("=", 80));
	//System.out.println();
	//PEMWriter pemWriter = new PEMWriter(new PrintWriter(System.out));
	//pemWriter.writeObject(cert);
	//pemWriter.flush();
	//System.out.println();
	//
	//System.out.println(Strings.repeat("=", 80));
	//System.out.println("PRIVATE KEY PEM (to store in a priv-johndoe.pem file)");
	//System.out.println(Strings.repeat("=", 80));
	//System.out.println();
	//pemWriter.writeObject(keyPair.getPrivate());
	//pemWriter.flush();
	
	
	}
	public void generarLlaveSesion(byte[] session) throws Exception
	{
		try 
		{
			Cipher cipher = Cipher.getInstance(ASIMETRICO);
			cipher.init(Cipher.DECRYPT_MODE, privateKeyRSA);
			byte [] textoPlano = cipher.doFinal(session);
			sessionKey = new SecretKeySpec(textoPlano, SIMETRICO);
		} 

		catch (Exception e) 
		{
			// TODO: handle exception
			throw new Exception("Error al descifrar");
		}
	}

	public void verificarCertificado(byte[] datosCertificado) 
	{
		try
		{
			X509Certificate certificado = X509Certificate.getInstance(datosCertificado);   
			certificado.checkValidity();
			PublicKey pKey = certificado.getPublicKey();
			setPublicKeyServer(pKey);
		} 

		catch (Exception e)
		{
			e.printStackTrace();
		}
	}

	public byte[] procesarINIT(String datos) throws Exception
	{
		String [] numeros = datos.split(";");
		byte[] bytes = new byte[numeros.length];

		for (int i = 0; i < bytes.length; i++) 
		{
			Integer numero = Integer.parseInt(numeros[i]);
			bytes[i] = numero.byteValue();
		}

		byte[] bytesDescifrados = descrifrarAsimetrico(bytes);

		return bytesDescifrados;
	}

	public byte[] descrifrarAsimetrico(byte[] bytes) throws Exception
	{
		try 
		{
			Cipher cipher = Cipher.getInstance(ASIMETRICO);
			cipher.init(Cipher.DECRYPT_MODE, publicKeyServer);
			byte [] textoPlano = cipher.doFinal(bytes);
			return textoPlano;
		} 

		catch (Exception e) 
		{
			// TODO: handle exception
			throw new Exception("Error descifrando");

		}
	}

	public String procesarPeticion(String id) throws Exception
	{
		try 
		{
			byte [] textoCifrado = null;
			byte [] textoPlano = id.getBytes();
			Cipher cipher = Cipher.getInstance(PADDING_SIMETRICO);
			cipher.init(Cipher.ENCRYPT_MODE, sessionKey);
			textoCifrado = cipher.doFinal(textoPlano);
			
			String respuestaCifrada = new String ("");
			
			for (int i = 0; i < textoCifrado.length; i++) 
			{
				byte actual = textoCifrado[i];
				if(i != textoCifrado.length-1)
				{
					respuestaCifrada += Byte.toString(actual)+PUNTO_COMA;
				}
				
				else
				{
					respuestaCifrada += Byte.toString(actual);
				}
			}
			
			return 	respuestaCifrada;
		} 

		catch (Exception e) 
		{
			throw new Exception("Error al encriptar sesion");
		}
	}
	
	public String procesarEstadoPedido(String cifrado) throws Exception
	{
		try 
		{
			String respuestaDescifrada = new String ("");
			
			String [] numeros = cifrado.split(";");
			byte[] bytes = new byte[numeros.length];

			for (int i = 0; i < bytes.length; i++) 
			{
				Integer numero = Integer.parseInt(numeros[i]);
				bytes[i] = numero.byteValue();
			}
			
			byte[] textoCifrado = bytes;
			Cipher cipher = Cipher.getInstance(PADDING_SIMETRICO);
			cipher.init(Cipher.DECRYPT_MODE, sessionKey);
			byte[] textoPlano = cipher.doFinal(textoCifrado);
			
			respuestaDescifrada = new String(textoPlano);
			
			return 	respuestaDescifrada;
		} 

		catch (Exception e) 
		{
			throw new Exception("Error al desencriptar estado");
		}
	}
	
	public String generarDigest(String cifrado)
	{
		String digest = new String("");
		
		MessageDigest md;
		try 
		{
			md = MessageDigest.getInstance(DIGEST);
			md.update(cifrado.getBytes(),0,cifrado.getBytes().length);
			StringBuffer sb = new StringBuffer(new BigInteger(1,md.digest()).toString(16));
			while (sb.length() < 32)
			{
				sb.insert(0,"0");
			}
			digest = sb.toString();
		} 
		
		catch (NoSuchAlgorithmException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return digest;
	}
	
	public boolean verificarDigest(String digestMensaje, String digestGenerado)
	{
		boolean coincide = false;
		
		int verificacion = digestMensaje.compareTo(digestGenerado);
		
		if(verificacion == 0)
		{
			coincide = true;
		}
		
		return coincide;
	}
	
	//Getters y Setters

	public SecretKey getSecretKeyAES() 
	{
		return secretKeyAES;
	}

	public void setSecretKeyAES(SecretKey secretKeyAES) 
	{
		this.secretKeyAES = secretKeyAES;
	}

	public KeyPair getKeyPairRSA() 
	{
		return keyPairRSA;
	}

	public void setKeyPairRSA(KeyPair keyPairRSA) 
	{
		this.keyPairRSA = keyPairRSA;
	}

	public PublicKey getPublicKeyRSA() 
	{
		return publicKeyRSA;
	}

	public void setPublicKeyRSA(PublicKey publicKeyRSA) 
	{
		this.publicKeyRSA = publicKeyRSA;
	}

	public PrivateKey getPrivateKeyRSA() 
	{
		return privateKeyRSA;
	}

	public void setPrivateKeyRSA(PrivateKey privateKeyRSA)
	{
		this.privateKeyRSA = privateKeyRSA;
	}

	public PublicKey getPublicKeyServer() 
	{
		return publicKeyServer;
	}

	public void setPublicKeyServer(PublicKey publicKeyServer)
	{
		this.publicKeyServer = publicKeyServer;
	}

	public KeyPair getKeyPairSHA() 
	{
		return keyPairSHA;
	}

	public void setKeyPairSHA(KeyPair keyPairSHA) 
	{
		this.keyPairSHA = keyPairSHA;
	}

	public SecretKeySpec getSessionKey() 
	{
		return sessionKey;
	}

	public void setSessionKey(SecretKeySpec sessionKey) 
	{
		this.sessionKey = sessionKey;
	}	
}